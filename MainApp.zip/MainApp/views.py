from django.shortcuts import render
import json
from django.core.paginator import Paginator

with open('Data/file.json') as data:
    countries = json.load(data)

dc = dict(countries)
name = 'Artem'
surname = 'Gubarev'
a_z = list(map(chr, range(65, 91)))
def home(request):
    return render(request, 'index.html')

def listl(request, letter=""):
    countries1 = []
    for i in countries:
        if i["country"][0:1] == letter:
            countries1.append(i)
    context = {
        "countries": countries1,
        "alphabet": a_z,
        "letter": letter,
        'id': dc
    }
    return render(request, 'countryaz.html', context)

def page(request, name=""):
    context = {
        "countries": countries,
        'target': name
    }
    return render(request, 'country_page.html', context)

def listg(request, numb):
    glist = []
    paginator_15 = Paginator(countries, 15)
    page_number = request.GET.get('page')
    page_obj = paginator_15.get_page(numb)
    for i in range(paginator_15.num_pages):
        glist.append(i+1)
    return render(request, 'list.html', {'page_obj': page_obj, "alphabet": a_z,    'count': glist,
 'title': numb})

def langlist(request):
    a_z = list(map(chr, range(65, 91)))
    language = []
    unic = []
    unicum = []
    for i in countries:
        massi = list(i['languages'])
        for a in massi:
            language.append(a)
            unic = set(language)
    for i1 in a_z:
        for i2 in unic:
            if i2[0] == i1:
                unicum.append(i2)

    context = {
        'lang': unic,
        'list': unicum
    }
    return render(request, 'languages.html', context)

def langpage(request, lang=''):
    lali = []
    for i in countries:
        for m in i['languages']:
            if m == lang:
                lali.append(i['country'])
    contro = lali

    context = {
        'smotr': lang,
        'stroi': contro
    }
    return render(request, 'lang_page.html', context)


def sty(request):
    return render(request, 'style.css')

def test(request, numb):
    a_z = list(map(chr, range(65, 91)))
    fatal = []
    language = []
    unic = []
    unicum = []
    for i in countries:
        massi = list(i['languages'])
        for a in massi:
            language.append(a)
            unic = set(language)
    for i1 in a_z:
        for i2 in unic:
            if i2[0] == i1:
                unicum.append(i2)
    fatal = unicum
    glist = []
    paginator_15 = Paginator(fatal, 15)
    page_obj = paginator_15.get_page(numb)
    for i in range(paginator_15.num_pages):
        glist.append(i+1)

    context = {
        'lang': unic,
        'list': unicum,
        'page_obj': page_obj,
        "alphabet": a_z,
        'count': glist,
        'title': numb
    }
    return render(request, 'test.html', context)
